using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;

namespace ServiceTest
{
    public class MyService:Service
    {
        public const string Tag = "MyService";

        private void write(int id, string text)
        {
            Log.Info(Tag, "{0} {1}:{2}  {3}", DateTime.Now, Tag, id,  text);
        }

        private void write(string text)
        {
            Log.Info(Tag, "{0} {1}    {3}", DateTime.Now, Tag, text);
        }


        public override IBinder OnBind(Intent intent)
        {
            return null;
        }

        public override void OnCreate()
        {
            base.OnCreate();
            write("OnCreate");
        }

        public override void OnDestroy()
        {
            base.OnDestroy();
            write("OnDestroy");
        }

        public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
        {
            write(startId, "OnStartCommand");

            for (int i = 0; i < 100000; i++)
            {
                for (int j = 0; j < 100000; j++)
                {
                    for (int l = 0; l < 100000; l++)
                    {

                    }

                }

            }

            return base.OnStartCommand(intent, flags, startId);
        }
    }
}