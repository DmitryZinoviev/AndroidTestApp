﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace ServiceTest
{
    [Activity(Label = "ServiceTest", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        int count = 1;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            // Get our button from the layout resource,
            // and attach an event to it
            Button startButton = FindViewById<Button>(Resource.Id.StartButton);

            startButton.Click += StartButtonOnClick;

            Button stopButton = FindViewById<Button>(Resource.Id.StopButton);

            stopButton.Click += StopButtonOnClick;

        }

        private void StopButtonOnClick(object sender, EventArgs eventArgs)
        {
            StartService(new Intent(this, typeof(MyService)));
        }

        private void StartButtonOnClick(object sender, EventArgs eventArgs)
        {
            StopService(new Intent(this, typeof(MyService)));
        }
    }
}

